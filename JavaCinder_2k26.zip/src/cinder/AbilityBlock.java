package cinder;

import arc.struct.Seq;
import mindustry.entities.abilities.Ability;
import mindustry.gen.Unit;
import mindustry.content.UnitTypes;
import mindustry.world.Block;

public class AbilityBlock extends Block {
    // Тот самый массив абилок, как у юнитов. 
    // Благодаря этому парсер Mindustry сможет читать блок из .hjson файлов!
    public Seq<Ability> abilities = new Seq<>();

    public AbilityBlock(String name) {
        super(name);
        this.update = true;
        this.solid = true;
        this.size = 2;
    }

    @Override
    public class AbilityBuild extends Building {
        // Скрытый юнит-пустышка, к которому будут «привязаны» абилки
        public Unit dummyUnit;

        @Override
        public void created() {
            super.created();
            // Создаем легкий юнит (например, alpha), но НЕ добавляем его в глобальные группы (Groups.unit),
            // чтобы враги его не атаковали и игра не считала его реальной боевой единицей.
            dummyUnit = UnitTypes.alpha.create(team);
            dummyUnit.set(x, y);
            
            // Инициализируем абилки для этого юнита
            for (int i = 0; i < abilities.size; i++) {
                abilities.get(i).init(dummyUnit);
            }
        }

        @Override
        public void update() {
            super.update();

            if (dummyUnit != null) {
                // Синхронизируем координаты и команду фантомного юнита со зданием
                dummyUnit.set(x, y);
                dummyUnit.team = team;
                dummyUnit.dead = !enabled; // Если блок отключен (нет энергии), выключаем абилки

                // Если блок работает, вызываем обновление ванильных абилок
                if (enabled) {
                    for (int i = 0; i < abilities.size; i++) {
                        abilities.get(i).update(dummyUnit);
                    }
                }
            }
        }

        @Override
        public void drawSelect() {
            super.drawSelect();
            if (dummyUnit != null) {
                dummyUnit.set(x, y);
                // Отрисовка радиуса абилок (например, круга EnergyFieldAbility)
                for (int i = 0; i < abilities.size; i++) {
                    abilities.get(i).draw(dummyUnit);
                }
            }
        }

        @Override
        public void remove() {
            // Удаляем юнит при разрушении/продаже блока, чтобы не было утечки памяти
            if (dummyUnit != null) {
                dummyUnit.remove();
            }
            super.remove();
        }
    }
}
