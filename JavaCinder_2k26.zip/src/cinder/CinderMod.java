package cinder;

import mindustry.mod.Mod;

public class CinderMod extends Mod {
    public CinderMod() {
    }

    @Override
    public void loadContent() {
    }
}
